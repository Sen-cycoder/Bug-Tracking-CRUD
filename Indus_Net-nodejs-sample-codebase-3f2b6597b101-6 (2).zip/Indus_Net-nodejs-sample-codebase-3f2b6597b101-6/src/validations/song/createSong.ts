import { celebrate, Joi } from 'celebrate';

export const createSong = celebrate({
  body: Joi.object({
    // Optional offset parameter for pagination
    title: Joi.string().required(),
    artist: Joi.string().required(), // Optional filter by artist
    album: Joi.string().required(), // Optional filter by album
    genre: Joi.string().required(), // Optional filter by genre
    release_date: Joi.date().required(), // Optional filter by release date
    duration: Joi.number().integer().min(0).required(), // Optional filter by duration
  }),
});
