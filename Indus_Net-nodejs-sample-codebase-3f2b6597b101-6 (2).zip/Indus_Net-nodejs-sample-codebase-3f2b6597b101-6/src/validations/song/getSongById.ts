import { celebrate, Joi } from 'celebrate';

export const getSongById = celebrate({
  body: Joi.object({
    // Optional offset parameter for pagination
    title: Joi.string().optional(),
    artist: Joi.string().optional(), // Optional filter by artist
    album: Joi.string().optional(), // Optional filter by album
    genre: Joi.string().optional(), // Optional filter by genre
    release_date: Joi.date().optional(), // Optional filter by release date
    duration: Joi.number().integer().min(0).optional(), // Optional filter by duration
  }),
});
