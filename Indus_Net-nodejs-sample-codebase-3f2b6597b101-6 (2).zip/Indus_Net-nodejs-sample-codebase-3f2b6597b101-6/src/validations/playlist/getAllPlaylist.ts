import { celebrate, Joi } from 'celebrate';

export const getAllPlaylist = celebrate({
  body: Joi.object({
    // Optional offset parameter for pagination
    name: Joi.string().required(),
    description: Joi.string().optional(), // Optional filter by artist
  }),
});
