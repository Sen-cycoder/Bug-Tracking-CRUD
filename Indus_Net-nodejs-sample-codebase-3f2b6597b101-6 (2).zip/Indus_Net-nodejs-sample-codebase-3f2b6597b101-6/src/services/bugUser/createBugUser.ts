import { IbugUser } from '@modules/bugUser/model';
import { bugSchema } from '@modules/bugUser/schema';

/**
 * Service function to create a new User using Sequelize
 * @param data Object containing user details to be created
 * @returns Promise resolving to the created user object
 */
export const createBug = async (data: IbugUser) => {
  const bugUser = await bugSchema.create({
    user_id: data.user_id,
    id: data.id,
  });
  return bugUser;
};
