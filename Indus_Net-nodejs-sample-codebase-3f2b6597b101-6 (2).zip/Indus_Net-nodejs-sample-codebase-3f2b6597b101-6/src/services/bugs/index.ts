// import { getSongById } from './getSongById';
import { getAllBug } from './getAllBug';
import { updateBugById } from './updateBug';
import { getBugById } from './getBugsById';
import { deleteBugById as Bug } from './deleteBug';
import { createBug } from './createBug';
// import { createSong } from './createSong';
// import { deleteSongById } from './deleteSong';
// import { updateSongById } from './updateSongById';

export { getAllBug, updateBugById, getBugById, Bug, createBug };
