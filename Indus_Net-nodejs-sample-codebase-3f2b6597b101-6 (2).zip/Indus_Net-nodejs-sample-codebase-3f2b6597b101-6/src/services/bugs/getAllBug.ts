import { BugSchema } from '@modules/bugs/schema';

export const getAllBug = async () => {
  return BugSchema.findAll();
};
