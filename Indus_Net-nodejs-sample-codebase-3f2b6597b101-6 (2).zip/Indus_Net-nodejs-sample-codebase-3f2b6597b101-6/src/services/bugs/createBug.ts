import { ICreateBugRequest } from '@modules/bugs/model';
import { BugSchema } from '@modules/bugs/schema';

/**
 * Service function to create a new song using Sequelize
 * @param data Object containing song details to be created
 * @returns Promise resolving to the created song object
 */
export const createBug = async (data: ICreateBugRequest) => {
  const bug = await BugSchema.create({
    title: data.title,
    description: data.description,
    status: data.status,
    Priority: data.priority,
  });

  return bug;
};
