import { BugSchema } from '@modules/bugs/schema'; // Adjust import path based on your project structure
// Adjust import path based on your project structure

/**
 * Service function to retrieve a song by its ID using Sequelize
 * @param id ID of the song to retrieve
 * @returns Promise resolving to the song object or null if not found
 */
export const getBugById = async (id: string) => {
  return BugSchema.findByPk(id);
};
