import { BugSchema } from '@modules/bugs/schema'; // Adjust import path based on your project structure

/**
 * Service function to delete a song by its ID using Sequelize
 * @param id ID of the song to delete
 * @returns Promise resolving to true if deletion was successful, false otherwise
 */
export const deleteBugById = async (id: string) => {
  const bug = await BugSchema.findByPk(id);

  if (!bug) {
    return false; // Song not found
  }
  await bug.destroy();
  return true;
};
