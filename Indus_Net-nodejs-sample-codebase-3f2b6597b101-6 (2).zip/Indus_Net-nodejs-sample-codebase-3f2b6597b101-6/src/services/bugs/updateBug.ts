import { BugSchema } from '@modules/bugs/schema';
import { ICreateBugRequest } from '@modules/bugs/model';

/**
 * Service function to update a song by its ID using Sequelize
 * @param id ID of the song to update
 * @param data Object containing updated song details
 * @returns Promise resolving to the updated song object or null if not found
 */
export const updateBugById = async (id: string, data: Partial<ICreateBugRequest>) => {
  const bug = await BugSchema.findByPk(id);

  if (!bug) {
    return null;
  }

  await bug.update({
    id: data.title,
    title: data.title,
    description: data.description,
    status: data.status,
    Priority: data.priority,
  });

  return bug;
};
