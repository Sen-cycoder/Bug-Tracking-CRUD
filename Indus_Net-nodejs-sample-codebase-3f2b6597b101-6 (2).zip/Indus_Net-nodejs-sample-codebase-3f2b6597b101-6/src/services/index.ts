import * as userService from './users';
import * as BugService from './bugs';
import * as BugUser from './bugUser';

export { userService, BugService, BugUser };
