import { Router } from 'express';
import { bugUserController } from '@controllers/index';

const buguserRouter = Router();

buguserRouter.post('/addbuguser', bugUserController.createuserBug);

export { buguserRouter };
