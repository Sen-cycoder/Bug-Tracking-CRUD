// v1Router.ts

import { Router } from 'express';
import { authRouter } from './auth'; // Adjust path based on your project structure
import { userRouter } from './user'; // Adjust path based on your project structure
import { bugRouter } from './bugs';
import { buguserRouter } from './bugUser';
// Adjust path based on your project structure

const v1Router = Router();

v1Router.use('/auth', authRouter);
v1Router.use('/user', userRouter);
v1Router.use('/bugs', bugRouter);
v1Router.use('/userbugs', buguserRouter);

export { v1Router };
