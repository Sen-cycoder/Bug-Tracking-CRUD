import { Router } from 'express';
import { bugController } from '@controllers/index';

const bugRouter = Router();

// // GET all Bugs
bugRouter.get('/', bugController.getAllBug);
bugRouter.get('/get/:id', bugController.getBugById);
bugRouter.put('/update/:id', bugController.updateBugById);
bugRouter.delete('/delete/:id', bugController.deleteBugById);
bugRouter.post('/create', bugController.createBug);

export { bugRouter };
