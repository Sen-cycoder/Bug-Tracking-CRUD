import * as Sequelize from 'sequelize';

export interface IbugUser extends Sequelize.Model {
  bug_id: number;
  user_id: number;
  id?: number;
}

export interface ICreateBugRequest {
  bug_id: number;
  user_id: number;
  id?: number;
}
