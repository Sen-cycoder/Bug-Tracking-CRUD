// modules/playlists/schema.ts

import * as Sequelize from 'sequelize';
import { IbugUser } from './model';
import { sequelize } from '../../config/database/sql';
// Adjust import path based on your project structure

export const bugSchema = sequelize.define<IbugUser>(
  'bugUser',
  {
    bug_id: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    user_id: {
      type: Sequelize.INTEGER,
      allowNull: true,
    },
    id: {
      type: Sequelize.INTEGER,
      allowNull: true,
    },
  },
  {
    timestamps: false, // Optional: Adds createdAt and updatedAt fields
  },
);
