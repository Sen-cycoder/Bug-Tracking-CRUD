import * as Sequelize from 'sequelize';

export interface IBug extends Sequelize.Model {
  id: number;
  title: string;
  description?: string;
  status?: string;
  priority?: string;
}

export interface ICreateBugRequest {
  title: string;
  description?: string;
  status?: string;
  priority?: string;
}
