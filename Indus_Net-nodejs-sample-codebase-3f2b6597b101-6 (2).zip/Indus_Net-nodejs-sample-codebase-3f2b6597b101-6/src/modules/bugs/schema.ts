// modules/songs/schema.ts

import * as Sequelize from 'sequelize';
import { IBug } from './model';
import { sequelize } from '../../config/database/sql';

export const BugSchema = sequelize.define<IBug>(
  'bugs',
  {
    id: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    title: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    description: {
      type: Sequelize.STRING,
      allowNull: true,
    },
    status: {
      type: Sequelize.STRING,
      allowNull: true,
    },
    priority: {
      type: Sequelize.STRING,
      allowNull: true,
    },
  },
  {
    timestamps: false,
  },
);
