import { Request, Response } from 'express';
import * as bugService from '@services/bugs/updateBug'; // Adjust import path based on your project structure

/**
 * Controller to handle the update of a song
 * @param req Express request object with song ID in params and updated song details in body
 * @param res Express response object
 */
export const updateBugById = async (req: Request, res: Response) => {
  const { id } = req.params;
  const updatedBugData = req.body;

  const bug = await bugService.updateBugById(id, updatedBugData);

  res.status(200).send(bug);
};
