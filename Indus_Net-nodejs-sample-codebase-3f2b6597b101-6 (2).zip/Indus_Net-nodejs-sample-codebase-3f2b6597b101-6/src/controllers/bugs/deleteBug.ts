import { Request, Response } from 'express';
import { BugService } from '@services/index';

/**
 * Controller to handle the deletion of a song by ID
 * @param req Express request object with song ID in params
 * @param res Express response object
 */
export const deleteBugById = async (req: Request, res: Response) => {
  const { id } = req.params;

  const deleted = await BugService.Bug(id);

  if (!deleted) {
    return res.status(404).send({ message: 'Bug not found' });
  }

  res.status(200).send({ message: 'Bug deleted' });
};
