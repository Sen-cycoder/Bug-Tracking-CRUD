import { Request, Response } from 'express';
import * as BugService from '@services/bugs/getBugsById'; // Adjust import path based on your project structure

/**
 * Controller to handle the retrieval of a song by ID
 * @param req Express request object with song ID in params
 * @param res Express response object
 */
export const getBugById = async (req: Request, res: Response) => {
  const { id } = req.params;
  const bug = await BugService.getBugById(id);

  if (!bug) {
    return res.status(404).send({ message: 'Bug not found' });
  }

  res.status(200).send(bug);
};

// Export the wrapped controller function
