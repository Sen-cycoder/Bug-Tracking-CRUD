import { Request, Response } from 'express';
import * as BugService from '@services/bugs/getAllBug';

/**
 * Retrieves all users.
 * @param _req - The request object.
 * @param res - The response object.
 * @returns A Promise that resolves to the list of users.
 */
export const getAllBug = async (_req: Request, res: Response) => {
  const bug = await BugService.getAllBug();
  res.status(200).send(bug);
};
