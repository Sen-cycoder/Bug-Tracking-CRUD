import { Request, Response } from 'express';
import * as BugService from '@services/bugs/createBug';

/**
 * Controller to handle the creation of a new song
 * @param req Express request object
 * @param res Express response object
 */
export const createBug = async (req: Request, res: Response) => {
  const bug = await BugService.createBug(req.body);
  res.status(201).send(bug);
};
