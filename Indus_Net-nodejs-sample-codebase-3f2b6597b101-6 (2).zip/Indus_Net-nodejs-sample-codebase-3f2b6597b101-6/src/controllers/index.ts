import * as authController from './auth';
import * as userController from './user';

import * as bugController from './bugs';
import * as bugUserController from './bugUser';

export { authController, userController, bugController, bugUserController };
