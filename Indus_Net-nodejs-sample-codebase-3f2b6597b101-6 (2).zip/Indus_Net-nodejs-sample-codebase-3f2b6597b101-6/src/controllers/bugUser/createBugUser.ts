import { Request, Response } from 'express';
import * as userBugService from '@services/bugUser/createBugUser';

/**
 * Controller to handle the creation of a new song
 * @param req Express request object
 * @param res Express response object
 */
export const createuserBug = async (req: Request, res: Response) => {
  const userBug = await userBugService.createBug(req.body);
  res.status(201).send(userBug);
};
