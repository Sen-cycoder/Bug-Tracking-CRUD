import * as shell from 'shelljs';

shell.cp('-R', 'src/assets', 'dist/');
